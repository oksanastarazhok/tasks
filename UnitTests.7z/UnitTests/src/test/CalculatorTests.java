package test;

import com.epam.tat.module4.Timeout;
import org.omg.CORBA.TIMEOUT;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class CalculatorTests extends BaseTest{

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForSubtraction",groups = "test long",dependsOnGroups = "double")
    public void testSub(long first, long second, long expected){
        long sub = calculator.sub(first,second);
        Assert.assertEquals(sub,expected);
}

    @DataProvider(name = "dataForSubtraction")
    public static java.lang.Object[][]dataForSubtraction() {
        return new java.lang.Object[][]{
                {100,50, 50},{- 1, - 1, - 2},
                {- 1, 1, - 2},{5, 10, - 5},{5, -10, - 5}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "testForDouble", groups="double")
    public void firstMinusSecond(double first, double second, double expected){
        double sub = calculator.sub(first,second);
        Assert.assertEquals(sub,expected);
    }

    @DataProvider(name = "testForDouble")
    public static java.lang.Object[][]testForDouble() {
        return new java.lang.Object[][]{
                {5.5, 5.5, 0},{- 1.85, - 1.15, - 3.0}, {0, 1.5, - 1.5}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForMultiplaying",groups = "test long", dependsOnGroups = "double")
    public void testMult(long first, long second, long expected){
        long mult = calculator.mult(first,second);
        Assert.assertEquals(mult,expected);
    }

    @DataProvider(name = "dataForMultiplaying")
    public static java.lang.Object[][]dataForMultiplaying() {
        return new java.lang.Object[][]{
                {0,100, 0}, {- 1, - 1, 1},{7, 7, 49}, {-5, 5, -25}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForMultDbl", groups = "double")
    public void firstMultipliedOnSecond(double first, double second, double expected){
        double mult = calculator.mult(first,second);
        Assert.assertEquals(mult,expected);
    }

    @DataProvider(name = "dataForMultDbl")
    public static java.lang.Object[][]dataForMultDbl() {
        return new java.lang.Object[][]{
                {0,100.00, 0},{- 1.00, - 1.00, 1.00},
                {0.5, 0.5, 0.25},{-5.0, 5.0, -25.00}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForPow", groups = "double")
    public void testPow(double first, double second, double expected){
        double pow = calculator.pow(first,second);
        Assert.assertEquals(pow,expected);
    }

    @DataProvider(name = "dataForPow")
    public static java.lang.Object[][]dataForPow() {
        return new java.lang.Object[][]{
                {10, 2, 100}, {-1, -1, -1}, {5.5, 3, 166.375},{25, -1, 0.04}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForDivision",groups = "test long", dependsOnGroups = "double")
    public void testDivision(long first, long second, long expected){
        long div = calculator.div(first,second);
        Assert.assertEquals(div,expected);
    }

    @DataProvider(name = "dataForDivision")
    public static java.lang.Object[][]dataForDivision() {
        return new java.lang.Object[][]{
                {100,50, 2},{- 1, - 1, 1},{0, 1, 0}};
    }

    @Parameters({"first", "second", "expected"})
    @Test(dataProvider = "dataForDivDbl", groups = "double")
    public void firstDivideOnSecond(double first, double second, double expected){
        double div = calculator.div(first,second);
        Assert.assertEquals(div,expected);
    }

    @DataProvider(name = "dataForDivDbl")
    public static java.lang.Object[][]dataForDivDbl() {
        return new java.lang.Object[][]{
                {100.00,50.00, 2.00},{- 1.5, - 1.2, 1.25} };
    }

    @Parameters({"first",  "expected"})
    @Test(dataProvider = "dataForSin", groups = "double")
    public void sinOfNumber(double first, double expected){
        double sin = calculator.sin(first);
        Assert.assertEquals(sin,expected);
    }

    @DataProvider(name = "dataForSin")
    public static java.lang.Object[][]dataForSin() {
        return new java.lang.Object[][]{
                {90, 1},{ 360, 0},{ 180, 0},{ 270, -1 }};
    }

    @Parameters({"first",  "expected"})
    @Test(dataProvider = "dataForCos", groups = "double")
    public void cosOfNumber(double first, double expected){
        double cos = calculator.cos(first);
        Assert.assertEquals(cos,expected);
    }

    @DataProvider(name = "dataForCos")
    public static java.lang.Object[][]dataForCos() {
        return new java.lang.Object[][]{
                {0, 1},{90, 0},{ 360, 1.0},{ 180, - 1.0}};
    }

    @Parameters({"first",  "expected"})
    @Test(dataProvider = "dataForTg", groups = "double")
    public void tgOfNumber(double first, double expected){
        double tg = calculator.tg(first);
        Assert.assertEquals(tg,expected);
    }

    @DataProvider(name = "dataForTg")
    public static java.lang.Object[][]dataForTg() {
        return new java.lang.Object[][]{
                {0, 0},{180, 0},{ 360, 0},{90,0}};
    }

    @Parameters({"first",  "expected"})
    @Test(dataProvider = "dataForCtg", groups = "double")
    public void ctgOfNumber(double first, double expected){
        double ctg = calculator.ctg(first);
        Assert.assertEquals(ctg,expected);
    }

    @DataProvider(name = "dataForCtg")
    public static java.lang.Object[][]dataForCtg() {
        return new java.lang.Object[][]{
                {0, 0},{180, 1.0},{ 360, 1.0}};
    }

    @Parameters({"first",  "expected"})
    @Test(dataProvider = "dataForSqrt", groups = "double")
    public void sqrtOfNumber(double first, double expected){
        double sqrt = calculator.sqrt(first);
        Assert.assertEquals(sqrt,expected);
        checkTime();
        Timeout.sleep(2);
    }

    @DataProvider(name = "dataForSqrt")
    public static java.lang.Object[][]dataForSqrt() {
        return new java.lang.Object[][]{
                {9, 3}, {- 1, 1.0}, { -25.00, 5},{0, 0}};
    }

    @Test(expectedExceptions = NumberFormatException.class, expectedExceptionsMessageRegExp = "Attempt to divide by zero")
    public void devisionOnZero(){
        calculator.div(1,0);
    }

    @Test(expectedExceptions = ArithmeticException.class, expectedExceptionsMessageRegExp = "Attempt to divide by zero")
    public void powDevisionOnZero(){calculator.pow(0,-1);
    }
}